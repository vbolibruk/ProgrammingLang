"""
Програма для демонстрації використання класів та пакетів
Fiction
Розробник: Vlad.
Версія: 1.0
"""
from custombooks import Fiction

newFiction = Fiction("Ono",13)
print(newFiction)
