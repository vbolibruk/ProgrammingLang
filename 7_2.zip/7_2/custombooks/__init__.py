from custombooks.Book import Book
from custombooks.Fiction import Fiction
from custombooks.NonFiction import NonFiction


# newFiction = Fiction("Ono",13)
# print(newFiction.price)
# newNonFiction = NonFiction("911",14)
# print(newNonFiction.price)