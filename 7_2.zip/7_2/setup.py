from setuptools import setup

setup(name='custombooks',
      version='0.1',
      description='The funniest joke in the world',
      url='http://github.com/20awesome/custombooks',
      author='Vlad',
      author_email='20awesome@gmail.com',
      license='MIT',
      packages=['custombooks'],
      zip_safe=False)